#include "obj.h"
#include <stdio.h>

int main()
{
  unsigned int bytes_get = stack_alloc(30);
}