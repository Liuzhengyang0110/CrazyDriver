main()
{
    int x, j, k, t, s;
    x = 2;
    s = 0;
    if(k){
        if(k > 10){
            s = -1;
        }
        else{
            s = -2;
        }
    }
    else{
        k = 10 / j;
        s = -3;
    }
    x = 4;
    print(x);
    print(j);
    print(k);
}