main()
{
    int i, j, k, x, a, b, c, d;
    i = 1;
    k = 1;
    j = i + 2;
    x = j;
    if(b){
        x = 4;
    }
    else{
        x = 5;
    }
    if(j){
        j = 10;
    }
    else{
        j = 20;
    }
    a = x * j;
    b = x * j;
    c = b * j;
    print(a);
    print(b);
    print(c);
}