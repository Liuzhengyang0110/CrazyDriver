main()
{
    int x, y, z, t;
    x = y;
    z = x;
    t = z;
}