main(){
    int a,b,c,d,e,f;
    a=3*b;
    c=6-e;
    d=3*b;
    f=6-e;
}