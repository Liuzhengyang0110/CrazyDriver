main()
{
	int i,j,k,l,m;
	i=8;
	j=i+2;
	k=i-3;
	l=i*2;
	m=i/2;
	printf("i=%d\n",i);
	printf("j=%d\n",j);
	printf("k=%d\n",k);
	printf("l=%d\n",l);
	printf("m=%d\n",m);
	return 0;
}
