int k;
main()
{
	int i,j;
	i=123;
	j=222;
	k=4;
	if(i!=j)
	{ 
		print("%d != %d", i, j); 
	}
	else
	{ 
		print("%d == %d", i, j); 
	}
	i=999;
	print("%d\n", i);
}

