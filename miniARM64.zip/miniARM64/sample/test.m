main()
{
	int i, j;
	i=1;
	if(i!=2)
	{ 
		j = 1;
	}
	else
	{ 
		j = 2;
        if(i != 1){
            j = 3;
        }
        j = 4;
	}
	print(i);
	print(j);
}