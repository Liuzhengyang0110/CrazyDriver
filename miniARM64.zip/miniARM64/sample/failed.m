main(){
    int x, y, z, t, c;
    x = 2;
    y = x * 4;
    if(x){
        y = x + 1;
        z = x * 5;
        t = y - 10;
    }
    else{
        y = 2;
        z = 3;
        t = 2;
    }
    x = t;
    y = x + 2;
    z = x + 2;
    print(x);
    print(y);
    print(z);
    print(t);
    print(c);

}