main()
{
    int x, y, z, k, t;
    y = x + 2;
    z = x + y;
    z = x;
    y = z;
    t = y;
    print(y);
    print(t);
}