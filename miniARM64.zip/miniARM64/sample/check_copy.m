main(){
    int x, y, z, t, c;
    y = x;
    z = y;
    t = z;
    c = t;
}