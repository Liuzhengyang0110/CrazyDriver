main(){
    int x, y;
    x = 2;
    if(x){
        if(1){
            y = 1;
        }
        else{
            y = 2;
        }
    }
    else{
        y = 3;
    }
}