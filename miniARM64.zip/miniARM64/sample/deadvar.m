main(){
    int x,y,z,s;
    x = 2;
    z = 1;
    s = 3;
    if(s==3){
        x = 4;
    }
    else {
        x = 5;
    }
    print(x);
}