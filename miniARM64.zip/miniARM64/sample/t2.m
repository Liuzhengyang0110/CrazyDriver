main()
{
    int x, y;
    x = 1;
    if(x){
        y = 1;
    }
    else{
        y = 2;
    }
    print(y);
}