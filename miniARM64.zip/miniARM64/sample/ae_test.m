main()
{
	int y,p,k,z,x,m;
	y=p-1;
    k=z/5;
    p=7*x;
    x=2*y;
    q=7*x;
    m=7*x;
    y=z/5;
}