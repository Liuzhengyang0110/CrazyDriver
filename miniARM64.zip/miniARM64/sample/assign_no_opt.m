main()
{
	int i,j,k,l,m,s;
	s=3;
	i=8;
	i=9;
	j=i+2;
	j=i+3;
	k=i-3;
	l=i*2;
	m=i/2;
	print("i=",i,"\n"); 
	print("j=",j,"\n"); 
	print("k=",k,"\n"); 
	print("l=",l,"\n"); 
	print("m=",m,"\n"); 
}
